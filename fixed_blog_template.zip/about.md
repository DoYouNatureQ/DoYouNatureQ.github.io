---
layout: page
title: 关于我
---

我是一位对文字、代码和幻觉世界充满兴趣的创造者。

> “代码即诗，梦境亦真。”

📮 联系方式：
- GitHub: [NatureQ](https://github.com/doyounatureq)
- 邮箱: doyougame@qq.com
