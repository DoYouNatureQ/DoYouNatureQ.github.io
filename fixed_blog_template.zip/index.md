---
layout: home
title: 主页
paginate: true
---

## 👋 欢迎来到我的博客！

你好，我是 NatureQ，一位独立游戏开发者。

- 🎮 热衷游戏开发与 Roguelike 设计
- 💊 研究虚构精神药理学和赛博主题
- 🧠 喜欢深度创作和心理构建

👉 最近文章：
